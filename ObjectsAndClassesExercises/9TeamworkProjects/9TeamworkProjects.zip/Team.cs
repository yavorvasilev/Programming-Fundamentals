﻿using System.Collections.Generic;

namespace _9TeamworkProjects
{
    public class Team
    {
        public string Name { get; set; }

        public List<string> Members { get; set; }

        public string NameOfCreator { get; set; }
    }
}
