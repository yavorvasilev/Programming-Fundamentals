﻿using System;
using System.Collections.Generic;

namespace _8MentorGroup
{
    public class Student
    {
        public string Name { get; set; }

        public List<string> Comments { get; set; }

        public List<DateTime> Attendency { get; set; }


    }
}
